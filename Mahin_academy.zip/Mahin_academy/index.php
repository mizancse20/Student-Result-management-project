<div style="width: 100%; height: px; margin-bottom: 0px;    color: #19ad24;"><h1 style="text-align: center; ">MAHIN ACADEMY</h1></div>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css" />

</head>
<body>
<!---navbar start-->
<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="result/">Result</a></li>
  <li><a href="contact.php">Contact</a></li>
  <li><a href="about.php">About</a></li>
</ul>
<!---navbar end-->
<!---slider start-->
<br>
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="img/img_nature_wide.jpg" style="width:100%">
  <div class="text">Gathering zone</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="img/img_snow_wide.jpg" style="width:100%">
  <div class="text">Classroom</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="img/img_mountains_wide.jpg" style="width:100%">
  <div class="text">Library</div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>
<!---navbar end-->
<br><br><br><br><br><br>
<div class="about-dis">
  <p> <h3>MAHIN ACADEMY</h3>
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort 
ListDropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort 
ListDropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
  </p>
  <p>
<h4>Dropdowns Accordions Side</h4>
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort
 ListDropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort 
ListDropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
  </p>
  <p>
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort
 ListDropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
<h4>Dropdowns Accordions Side</h4>
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort 
ListDropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps <b>Range Sliders Tooltips Slideshow</b> Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
  </p>
</div>



<div class="memed">
<div class="dscp">
<h3>Speech of Headmaster</h3>
  <img src="img/headmaster.png"><br>
  <p>
Tabs Dropdowns Accordions Side Navigation Top Navigation Modal Boxes Progress Bars Parallax Login Form HTML Includes Google Maps Range Sliders Tooltips Slideshow Filter List Sort List Dropdowns Accordions Side Navigation Top Navigation Modal Boxes Progress Bars Parallax Login Form HTML Includes Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders. Google Maps Range Sliders.
  </p>
</div>
<div class="dscp">
<h3>Speech of Secretary</h3>
  <img src="img/headmaster.png"><br>
  <p>
Tabs Dropdowns Accordions Side Navigation Top Navigation Modal Boxes Progress Bars Parallax Login Form HTML Includes Google Maps Range Sliders Tooltips Slideshow Filter List Sort List Dropdowns Accordions Side Navigation Top Navigation Modal Boxes Progress Bars Parallax Login Form HTML Includes Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort 
  </p>
</div>
<div class="dscp">
<p><h3>Speech of precident</h3>
  <img src="img/headmaster.png"> <br>
  
Tabs Dropdowns Accordions Side Navigation Top Navigation Modal Boxes Progress Bars Parallax Login Form HTML Includes Google Maps Range Sliders Tooltips Slideshow Filter List Sort List Dropdowns Accordions Side Navigation Top Navigation Modal Boxes Progress Bars Parallax Login Form HTML Includes Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes
Google Maps Range Sliders Tooltips Slideshow Filter List Sort List
Dropdowns Accordions Side Navigation Top Navigation
Modal Boxes Progress Bars Parallax Login Form HTML Includes.
Progress Bars Parallax.
  </p>
</div>

</div>

<br><br><br><br><br><br><br><br><br><br><br><br>

<!---footer start-->
<div class="footer">
  <p>&#169 All right reserved by_<a href="#">Mizan</a></p>
</div>

<!---footer end-->


</body>
</html> 