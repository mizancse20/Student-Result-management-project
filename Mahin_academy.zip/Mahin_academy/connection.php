<?php
$conn=mysqli_connect("localhost","root","","mahin_academy");
?>